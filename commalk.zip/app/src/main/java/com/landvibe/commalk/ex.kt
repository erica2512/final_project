package com.landvibe.commalk

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var btn_plus: Button? = null
    private var btn_Minus: Button? = null
    private var meaning: TextView? = null
    private var count = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        meaning = findViewById(R.id.meaning)
        meaning.setText(count.toString() + "")
        btn_plus = findViewById(R.id.btn_plus)
        btn_Minus = findViewById(R.id.btn_minus)
        btn_plus.setOnClickListener(View.OnClickListener {
            count++
            meaning.setText(count.toString() + "")
        })
        btn_Minus.setOnClickListener(View.OnClickListener {
            count--
            meaning.setText(count.toString() + "")
        })
    }
}